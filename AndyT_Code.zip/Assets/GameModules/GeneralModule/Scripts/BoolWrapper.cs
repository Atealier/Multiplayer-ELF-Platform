using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoolWrapper { public bool Value = false; }

