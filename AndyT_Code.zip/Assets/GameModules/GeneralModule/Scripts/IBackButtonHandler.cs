using UnityEngine;

public interface IBackButtonHandler
{
    void OnBackButtonPressed();
}