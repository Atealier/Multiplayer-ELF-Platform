using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnlineMultiplayerModule : MonoBehaviour,IStartButtonHandler
{

    //public class HeartRateModule : MonoBehaviour, IBackButtonHandler
    //{
    //    public void OnBackButtonPressed()
    //    {
    //        HeartRateUIManager.Instance.GoToMenu();
    //    }

    //}
        

    public void OnStartGameButtonPressed()
    {
        throw new System.NotImplementedException();
    }
}
